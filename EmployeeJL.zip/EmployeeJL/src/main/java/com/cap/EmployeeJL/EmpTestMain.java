import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.function.Predicate;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class EmpTestMain {

	 private static Employee getEmpObject(JSONObject emp) 
     {
	        
	    	Employee empObj = new Employee();
	    	
	    	empObj.setEmployeeId((long) emp.get("_id"));    
	        
	        JSONObject name = (JSONObject) emp.get("name");

	        empObj.setFirstname((String) name.get("first")); 
 
	        empObj.setLastname((String) name.get("last")); 

	        empObj.setSalary((double) emp.get("balance")); 
	        
	        empObj.setEyecolor((String) emp.get("eyeColor")); 

	        empObj.setCompany((String) emp.get("company"));  
	        
	        empObj.setEmail((String) emp.get("email"));   
	         
	        
	        
	        return empObj;
	        
	    }

	
	public static void main(String[] args)
    {
    	
        JSONParser jparser = new JSONParser();
         
        try (FileReader reader = new FileReader("employee"))
        {
            
            Object obj = jparser.parse(reader);
                
            
            ArrayList<Employee> empList = new ArrayList<Employee>();
            JSONArray empLists = (JSONArray) obj;
            int len = empLists.size();
            
            for(int i=0;i<len;i++)
            {
            	empList.add(getEmpObject((JSONObject)empLists.get(i)));
            }
            
                        
            Predicate<Employee> brown = empobj -> empobj.getEyecolor().equalsIgnoreCase("brown");
            
            Predicate<Employee> blue = empobj -> empobj.getEyecolor().equalsIgnoreCase("blue");
            
            Predicate<Employee> black = empobj -> empobj.getEyecolor().equalsIgnoreCase("black");
            
            System.out.println(empList.parallelStream().filter(black.or(blue).or(brown)).count());
            
            System.out.println(empList.parallelStream().filter(black).count());
            
            empList.parallelStream().filter(black.or(blue).or(brown)).forEach(emp -> System.out.println(emp));
 
        } catch (FileNotFoundException e) {
            e.printStackTrace();
          } catch (IOException e) {
            e.printStackTrace();
        } catch (org.json.simple.parser.ParseException e) {
			e.printStackTrace();
		}
    }
    
   }
