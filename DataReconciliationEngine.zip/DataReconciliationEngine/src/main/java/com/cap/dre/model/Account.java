package com.cap.dre.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Account {

	public String transactionId;
	public String accountId;
	public LocalDate postDate ;//= LocalDateTime.now();
	public Double amount;
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public LocalDate getPostDate() {
		return postDate;
	}
	public void setPosteDate(LocalDate postDate) {
		this.postDate = postDate;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Account(String transactionId, String accountId, LocalDate postDate, double amount) {
		super();
		this.transactionId = transactionId;
		this.accountId = accountId;
		this.postDate = postDate;
		this.amount = amount;
	}
	
	
	
	
	
}
