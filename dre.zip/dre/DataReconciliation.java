package com.cap.dre;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;

import com.cap.dre.model.Account;

public class DataReconciliation {
	static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-MMM-yyyy", Locale.ENGLISH);

	public static void main(String[] args) throws IOException {
	List<Account> xlist = readFile("X.txt");
	List<Account> ylist = readFile("Y.txt");

	String exactStr = "";
	String weekStr = "";
	String breakXStr = "";
	String breakYStr = "";

	Map<String, String> result = new HashMap<>();

	for (int i = 0; i < xlist.size(); i++) {
		Account xs = xlist.get(i);
		Account ys = ylist.get(i);
		//System.out.println("xs=="+xs+"ys=="+ys);
		if (xs.equals(ys)) {
			//System.out.println("quesssssssssssss");
			exactStr += xs.getTransactionId() + "" + ys.getTransactionId() + " ";
			result.put("EXACT", exactStr);
		} else if (xs.getAccountId().equals(ys.getAccountId()) && (xs.getAmount().equals(ys.getAmount()) || xs.getAmount().equals(ys.getAmount() - 0.01)) && (xs.getPostDate().equals(ys.getPostDate()) || dateCompareWeak(xs.getPostDate(), ys.getPostDate()))) {
				//xs.getAccountId().equals(ys.getAccountId()) && (xs.getAmount().equals(ys.getAmount()) || xs.getAmount().equals(ys.getAmount() - 0.01)) && (xs.getposteDate().equals(ys.getposteDate())
		//	|| dateCompareWeak(xs.getposteDate(), ys.getposteDate()))) {
			weekStr += xs.getTransactionId() + "" + ys.getTransactionId() + " ";
			result.put("WEAK", weekStr);
		} else {
			breakXStr += xs.getTransactionId()+" ";
			breakYStr += ys.getTransactionId()+" ";
			result.put("BREAKX", breakXStr);
			result.put("BREAKY", breakYStr);
		}

	}

	//result.forEach((k, v) -> System.out.println(k + "==" + v));
	System.out.println("#XY exact matches \n"+result.get("EXACT"));
	System.out.println("#XY weak matches \n"+result.get("WEAK"));
	System.out.println("#X breaks \n"+result.get("BREAKX"));

	System.out.println("#Y breaks \n"+result.get("BREAKY"));


	}
	
	

	public static boolean dateCompareWeak(LocalDate d1, LocalDate d2) {		

		if ((d1.getDayOfWeek().equals(DayOfWeek.FRIDAY)) && (d2.getDayOfWeek().equals(DayOfWeek.SATURDAY)
				|| d2.getDayOfWeek().equals(DayOfWeek.SUNDAY) || d2.getDayOfWeek().equals(DayOfWeek.MONDAY))) {
			return true;
		}

		if(d1.equals(d2.plusDays(-1))) {
			return true;
		}

		return false;
	}
	
	public static List<Account> readFile(String fileName) throws IOException {

		List<Account> ls = new ArrayList<Account>();
		try (Stream<String> stream = Files.lines(Paths.get(fileName), StandardCharsets.UTF_8)) {
			stream.forEach(s -> { 
				String[] ar = s.split(";");
				LocalDate dateTime = LocalDate.parse(ar[2].trim(), formatter);
				Account r = new Account(ar[0], ar[1], dateTime, Double.valueOf(ar[3]));
				ls.add(r);
			});
		} catch (IOException e) {
			e.printStackTrace();
		}

			return ls;
		}

}




